<!DOCTYPE html>
<html lang = "en">

    <head>

        <title>Apoorva Chitre</title>

        <link rel ="stylesheet" href ="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

        <link href="/css/style.css" rel="stylesheet" type="text/css">

        
    </head>
    <body>

    	<div class="container">

        	@yield('content')
    	
    	</div>
    	
    </body>
</html>