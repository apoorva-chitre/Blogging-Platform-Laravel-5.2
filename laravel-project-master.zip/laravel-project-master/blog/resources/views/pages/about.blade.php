@extends('layouts.app')


@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><h3>About Apoorva - yes that's me!</h3></div>

				<div class="panel-body">

                    <center><img src="{{URL::asset('/image/apoorva.jpg')}}" alt="profile Pic" height="500" width="500"></center>
                    <br>
                    <p style ="font-size:16px;">Welcome to my website. I have always believed that talent meets opportunity and Talent is that crazy combination of hard work, dedication, discipline and passion.</p>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection