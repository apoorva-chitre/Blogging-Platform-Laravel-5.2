@extends('layout')


@section('content')

	<h1>{{ $article->title}}

@stop