@extends('layouts.app')

@section('content')
@include('message-block')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">A little something about me.</div>

                <div class="panel-body">

                <div class="jumbotron">
  


                    <center><iframe width="700" height="450" src="https://www.youtube.com/embed/iANtc3me37Q" frameborder="0" allowfullscreen></iframe></center>
                    
                </div>
                        
            </div>
        </div>
    </div>
</div>
@endsection
